from flask import Flask, render_template, request
import joblib
import numpy as np
import os

app = Flask(__name__)

# Load model
model_path = os.path.join('model', 'random_forest_model.pkl')
model = joblib.load(model_path)

@app.route('/', methods=['GET', 'POST'])
def home():
    prediction_text = None

    if request.method == 'POST':
        # Ambil nilai input dari form
        features = [
            request.form.get('Age'),
            request.form.get('Gender'),
            request.form.get('Polyuria'),
            request.form.get('Polydipsia'),
            request.form.get('sudden_weight_loss'),
            request.form.get('weakness'),
            request.form.get('Polyphagia'),
            request.form.get('Genital_thrush'),
            request.form.get('visual_blurring'),
            request.form.get('Itching'),
            request.form.get('Irritability'),
            request.form.get('delayed_healing'),
            request.form.get('partial_paresis'),
            request.form.get('muscle_stiffness'),
            request.form.get('Alopecia'),
            request.form.get('Obesity')
        ]

        # Konversi ke array numpy dan ubah ke tipe float
        final_features = np.array([float(x) for x in features]).reshape(1, -1)

        # Prediksi dengan model
        prediction = model.predict(final_features)

        # Interpretasi hasil
        if prediction[0] == 1:
            prediction_text = "Pasien diprediksi MENGIDAP diabetes."
        else:
            prediction_text = "Pasien diprediksi TIDAK mengidap diabetes."

    return render_template('index.html', prediction_text=prediction_text)

if __name__ == '__main__':
    app.run(debug=True)
